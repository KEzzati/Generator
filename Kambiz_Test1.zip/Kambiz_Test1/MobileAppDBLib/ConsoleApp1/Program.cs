﻿using System;
using GenReader;  
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //GenReader. ReadJSon
            Main GenReader = new GenReader.Main();
            Console.WriteLine("Hello World!");
            GenReader.Run();
            Console.ReadKey();


        }
    }
}
