﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TypeDefs
{
    public class StatisticsManager
    {
        public double MinCache { get; set; }
        public double MaxCache { get; set; }
        public double SumCache { get; set; }
        public double AvgCache { get; set; }
        List<double> DataSetItems;
        public StatisticsManager(List<double> dataSetItems)
        {
            DataSetItems = dataSetItems;
        }
        public void UpdateStatistics()
        {
            try
            {
                if (DataSetItems.Count==0)
                {
                    Console.WriteLine("Error: DataSets has no entry.");
                    return;
                }
                double min = DataSetItems[0];
                double max = DataSetItems[0];
                double sum = 0;
                double avg = 0;

                foreach (var item in DataSetItems)
                {
                    min = (item < min ) ? item : min;
                    max = (item > max ) ? item : max;
                    sum += item;
                }
                avg = sum / (float)DataSetItems.Count;

                SumCache = sum;
                MinCache = min ;
                MaxCache = max ;
                AvgCache = avg;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        public double GetStatistics(OperationType operationType)
        {
            try
            {
                switch (operationType)
                {
                    case OperationType.min:
                        return MinCache;
                    case OperationType.max:
                        return MaxCache;
                    case OperationType.sum:
                        return SumCache;
                    case OperationType.avg:
                        return AvgCache;

                    default:
                        return 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return 0;
        }
    }
}
