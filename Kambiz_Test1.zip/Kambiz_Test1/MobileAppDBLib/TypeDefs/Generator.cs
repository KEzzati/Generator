﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace TypeDefs
{
    /// <summary>
    /// Represents Generator Object
    /// </summary>
    public class Generator
    {
        public string name { get; set; }
        public int interval { get; set; }
        public string operation { get; set; }

        public OperationType OperationEnum
        {
            get
            {
                var res = (OperationType)Enum.Parse(typeof(OperationType), operation);
                return res;
            }
        }

        public Thread JobThread { get; set; }

        public int CurrentIteration { get; set; } = 0;

        public List<List<double>> DataSets { get; set; }
        public void StartJob(List<List<double>> datasets)
        {
            DataSets = datasets;
            JobThread = new Thread(new ThreadStart(CalculateTask));
            JobThread.Start();
        }
        public Object CalculateLock = new object();

        private void CalculateTask()
        {
            for(int w=0;w<DataSets.Count;w++)
            {
                DateTime timeTag;
                double val;
                Calculate(out timeTag, out val);
                var currentTimeTag = timeTag.ToString("hh:mm:ss");
                
                Console.WriteLine(currentTimeTag + " "+name+" " + val.ToString("#.###"));
                Thread.Sleep(interval * 1000);
                CurrentIteration++;
            }
        }


        private void Calculate(out DateTime timeTag, out double val)
        {
            lock (CalculateLock)
            {
                timeTag = DateTime.Now;
                var CurrentDataSet = DataSets[CurrentIteration];
                StatisticsManager statisticManager = new StatisticsManager(CurrentDataSet);
                statisticManager.UpdateStatistics();
                var value = statisticManager.GetStatistics(OperationEnum);
                val = value;
            }
        }
    }
}