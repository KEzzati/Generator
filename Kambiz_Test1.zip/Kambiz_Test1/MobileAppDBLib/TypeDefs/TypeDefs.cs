﻿using System;

namespace TypeDefs
{
    public class TypeDefs
    {
    }

    public enum OperationType
    {
        sum,
        min,
        max,
        avg
    }
}
