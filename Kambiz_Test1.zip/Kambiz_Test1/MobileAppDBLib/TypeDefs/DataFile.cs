﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TypeDefs
{
    public class Root
    {
        public List<List<double>> datasets { get; set; }
        public List<Generator> generators { get; set; }
    }
}
