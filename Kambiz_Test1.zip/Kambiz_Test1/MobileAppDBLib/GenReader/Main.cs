﻿using GenReaderLib;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using TypeDefs;

namespace GenReader
{
    public class Main
    {
        Root Root { get; set; }
        public void ReadJSon(string dataFileName)
        {
            StreamReader r = new StreamReader(dataFileName);
            string jsonString = r.ReadToEnd();
            Root = JsonConvert.DeserializeObject<Root>(jsonString);        

        }
        public void Run()
        {
            ReadJSon("./Data.json");
            var generators = Root.generators;
            var dataSets   = Root.datasets;

            foreach (var gen in generators)
            {
                gen.StartJob(dataSets);
            }
        }
    }
}
