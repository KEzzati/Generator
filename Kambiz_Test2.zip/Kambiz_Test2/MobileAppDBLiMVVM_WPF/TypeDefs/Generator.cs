﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Collections.ObjectModel;

namespace TypeDefs
{
    /// <summary>
    /// Represents Generator Object
    /// </summary>
    public class Generator
    {
        [NonSerialized]
        public static int LastID;
        private Generator()
        {
            ID = LastID++;
        }
        public int ID { get; set; }
        public string name { get; set; }
        public int interval { get; set; }
        public string operation { get; set; }

        public OperationType OperationEnum
        {
            get
            {
                var res = (OperationType)Enum.Parse(typeof(OperationType), operation);
                return res;
            }
        }
        [NonSerialized]
        public Thread JobThread;

        [NonSerialized]
        public int CurrentIteration  = 0;

        [NonSerialized]
        public ObservableCollection<ObservableCollection<double>> DataSets;
        public void StartJob(ObservableCollection<ObservableCollection<double>> datasets)
        {
            DataSets = datasets;
            JobThread = new Thread(new ThreadStart(CalculateTask));
            JobThread.Start();
        }
        [NonSerialized]
        public Object CalculateLock = new object();

        private void CalculateTask()
        {
            for(int w=0;w<DataSets.Count;w++)
            {
                DateTime timeTag;
                double val;
                Calculate(out timeTag, out val);
                var currentTimeTag = timeTag.ToString("hh:mm:ss");

                WriteToLog(currentTimeTag + " "+name+" " + val.ToString("#.###"));
                Thread.Sleep(interval * 1000);
                CurrentIteration++;
            }
        }

        public void WriteToLog(string log)
        {
            if (WriteToLogHandler != null)
                WriteToLogHandler(log);
        }
        public WriteToLogDelegate WriteToLogHandler { get; set; }
        private void Calculate(out DateTime timeTag, out double val)
        {
            lock (CalculateLock)
            {
                timeTag = DateTime.Now;
                var CurrentDataSet = DataSets[CurrentIteration];
                StatisticsManager statisticManager = new StatisticsManager(CurrentDataSet);
                statisticManager.UpdateStatistics();
                var value = statisticManager.GetStatistics(OperationEnum);
                val = value;
            }
        }
    }
}