﻿using System;

namespace TypeDefs
{
    public class TypeDefs
    {
    }

    public enum OperationType
    {
        min,
        max,
        sum,
        avg
    }
    public delegate void WriteToLogDelegate(string text);
}
