﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TypeDefs
{
    public class Root
    {
        public ObservableCollection<ObservableCollection<double>> datasets { get; set; }
        public ObservableCollection<Generator> generators { get; set; }
    }
}
