﻿using GenReaderLib;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using TypeDefs;

namespace GenReader
{
    public class GeneratorModelManager
    {
        private static GeneratorModelManager _Instance;
        public static GeneratorModelManager Instance
        {
            get
            {
                if (_Instance == null)
                    _Instance = new GeneratorModelManager();
                return _Instance;
            }
        }

        public GeneratorModelManager()
        {
            RunLoadReadParallel();
        }
        Root Root { get; set; }
        public string DataFileName { get; set; }
        
        public void ReadJSon(string dataFileName)
        {
            if (Root != null)
                return;
            DataFileName = dataFileName;    
            StreamReader r = new StreamReader(dataFileName);
            string jsonString = r.ReadToEnd();
            Root = JsonConvert.DeserializeObject<Root>(jsonString);
            r.Close();
        }
        public void SaveJSon()
        {
            string fileName = DataFileName;
            string jsonString = JsonConvert.SerializeObject(Root);
            File.WriteAllText(fileName, jsonString);
        }
        public ObservableCollection<ObservableCollection<double>> Datasets 
        { 
            get
            {
                if (Root == null)
                    return new ObservableCollection<ObservableCollection<double>> { };
                var res = Root.datasets;
                return res;
            }
        }
        public ObservableCollection<Generator> Generators
        {
            get
            {
                var res = Root.generators;
                return res;
            }
        }

        public void RunLoadReadParallel(bool loadJson=true,bool runTask=false)
        {
            if (loadJson)
                ReadJSon("./Data.json");

            if (runTask)
            foreach (var gen in Generators)
            {
                gen.StartJob(Datasets);
            }
        }
    }
}
