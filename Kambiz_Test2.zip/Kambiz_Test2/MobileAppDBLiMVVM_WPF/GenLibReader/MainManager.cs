﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenReaderLib
{
    class MainManager
    {
        private MainManager() { }

        private static MainManager _instance;
        public static MainManager Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new MainManager();
                return _instance;
            }
        }
        public static void WriteError(string err)
        {
            Console.WriteLine("Error: " + err);
            //TODO: Add error Handing
        }
        public static void WriteError(Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
            //TODO: Add error Handing
        }
        public static void WriteInfo(string info)
        {
            Console.WriteLine("Info: " + info);
            //TODO: Add info Handing
        }
    }
}
