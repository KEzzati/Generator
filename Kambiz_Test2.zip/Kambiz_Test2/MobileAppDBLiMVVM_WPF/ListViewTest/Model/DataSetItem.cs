﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneratorWPF.Model
{
    public class DataSetItem
    {
        public DataSetItem(int idx,double val)
        {
            Index = idx;
            Value = val;
        }
        public int Index { get; set; }
        public double Value { get; set; }
    }
}
