﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using GeneratorWPF.Model;
using System.Collections.ObjectModel;

namespace GeneratorWPF
{
    public class GeneratorModel
    {
        public static GeneratorModel Instance { get; private set; }

        public GeneratorModel()
        {
            Instance = this;
            GenReader.GeneratorModelManager.Instance.RunLoadReadParallel();
        }
        public void SaveModel()
        {
            GenReader.GeneratorModelManager.Instance.SaveJSon();
        }
        public void UpdateGenerator(TypeDefs.Generator generator,bool saveFile=false)
        {
            var gen =GenReader.GeneratorModelManager.Instance.Generators.Where((x) => x.ID == generator.ID).FirstOrDefault();
            if (gen!=null)
            {
                gen.name = generator.name ;
                gen.interval = generator.interval;
                gen.operation = generator.operation;
            }
            if (saveFile)
                SaveModel();
        }

    }
}
