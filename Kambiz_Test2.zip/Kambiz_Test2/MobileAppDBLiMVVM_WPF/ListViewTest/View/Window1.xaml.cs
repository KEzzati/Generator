﻿using GeneratorWPF.Model;
using GeneratorWPF.ViewModel;
using GenReader;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TypeDefs;

namespace GeneratorWPF
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        private bool stopRefreshControls = false;
        private bool dataChanged = false;

        public Window1()
        {
            InitializeComponent();
            DataContext = new GeneratorViewModel();
            _timer = new Timer(1000);
            _timer.Elapsed += OnTimedEvent;
            _timer.Enabled = false;

            GeneratorViewModel.Instance.WriteToLogHandler -= new WriteToLogDelegate(WriteToLog);
            GeneratorViewModel.Instance.WriteToLogHandler += new WriteToLogDelegate(WriteToLog);
        }

        /// <summary>
        /// addButton click event handler.
        /// Add a new row to the ListView.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            setDataChanged(true);
            AddDataSetItem();
        }

        /// <summary>
        /// Adds a blank row to the ListView
        /// </summary>
        private void AddDataSetItem()
        {
            GeneratorViewModel.Instance.AddDataSetItem();
            lvDataSetDetail.SelectedIndex = lvDataSetDetail.Items.Count - 1;
            tbDataSetValue.Text = "";
            tbDataSetValue.Focus();
        }

        /// <summary>
        /// removeButton click event handler
        /// Removes the selected row from the ListView
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            setDataChanged(true);

            int selectedIndex = lvDataSetDetail.SelectedIndex;
            GeneratorViewModel.Instance.RemoveDataSetItemFromCurrentDataSet(selectedIndex);
            if (lvDataSetDetail.SelectedIndex>0 && lvDataSetDetail.Items.Count>0 && selectedIndex>1)
                lvDataSetDetail.SelectedIndex = selectedIndex-1;
            tbDataSetValue.Focus();

        }

        /// <summary>
        /// textBox1 TextChanged event handler
        /// Updates the ListView row with current Text 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox1_TextChanged(object sender, TextChangedEventArgs e)
        {
        }

        /// <summary>
        /// Refreshses the ListView row with given values
        /// </summary>
        /// <param name="value1">Value for column 1</param>
        /// <param name="value2">Value for column 2</param>
        private void RefreshGeneratorListView(string name, int interval, OperationType operationType)
        {
            TypeDefs.Generator lvc = (TypeDefs.Generator)lvGeneratorList.SelectedItem; 
            if (lvc != null && !stopRefreshControls)
            {
                setDataChanged(true);

                lvc.name = name;
                lvc.interval = interval;
                lvc.operation = operationType.ToString();

                lvGeneratorList.Items.Refresh();
            }
        }

        private void RefreshDataSetItemsListView(double newDSVal)
        {
            DataSetItem dsi = (DataSetItem)lvDataSetDetail.SelectedItem; 
            if (dsi != null && !stopRefreshControls)
            {
                setDataChanged(true);

                dsi.Value = newDSVal;   

                lvDataSetDetail.Items.Refresh();
            }
        }

        /// <summary>
        /// textBox2 TextChanged event handler
        /// Updates the ListView row with current Text 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox2_TextChanged(object sender, TextChangedEventArgs e)
        {
//            RefreshListView(textBox1.Text, textBox2.Text);
        }

        /// <summary>
        /// listView1 SelectionChnaged event handler.
        /// Updates the textboxes with values in the row.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void listView1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ObservableCollection<double> lvc = (ObservableCollection<double>)lvDataSetDetail.SelectedItem;
            if (lvc != null)
            {
                stopRefreshControls = true;
                lvDataSetDetail.DataContext = lvc;
                stopRefreshControls = false;
            }
        }

        /// <summary>
        /// Window Loaded event handler
        /// Loads data into ListView, and selecta a row.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ShowData();

            {
                lvGeneratorList.SelectedIndex = 0;
                lvDataSetList.SelectedIndex = 0;
                lvDataSetDetail.SelectedIndex = 0;
            }
            setDataChanged(false);
        //    textBox1.Focus();
        }

        /// <summary>
        /// Shows(Loads) data into the ListView
        /// </summary>
        private void ShowData()
        {
            GeneratorModel md = new GeneratorModel();
            //lvDataSetList.Items.Clear();
            //lvGeneratorList.Items.Clear();
            //lvDataSetDetail.Items.Clear();
//            lvDataSetDetail.ItemsSource = Dataset
//            foreach (var row in md.GetGeneratorRows())
//            {
//                lvGeneratorList.Items.Add(row);
//            }
//            foreach (var row in md.GetDataSetListRows())
//            {
//                lvDataSetList.Items.Add(row);
//            }
        }

        /// <summary>
        /// saveButton click event handler.
        /// Saves data from ListView, if it is changed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveButton_Click(object sender, RoutedEventArgs e)
        {
            double dsVal=0;
            double.TryParse(tbDataSetValue.Text, out dsVal);
            
            RefreshDataSetItemsListView(dsVal);

            GeneratorViewModel.Instance.SelecteDataSetItem.Value = dsVal;
            GeneratorViewModel.Instance.SelectedDataset.DataSetItems[lvDataSetDetail.SelectedIndex].Value = dsVal;
            GeneratorViewModel.Instance.SaveCurrentDataSet();
        }

        /// <summary>
        /// closeButton click event handler.
        /// Closes the window.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void closeButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// okButton click event handler.
        /// Saves the data, and closes the window.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void okButton_Click(object sender, RoutedEventArgs e)
        {
            okButton.IsEnabled = false;
            if (dataChanged)
            {
        //        MonitorModel md = new MonitorModel();
             //   md.Save(listView1.Items);
                setDataChanged(false);
            }
            this.Close();
        }

        /// <summary>
        /// Sets the window into a DataChanged status.
        /// </summary>
        /// <param name="value"></param>
        private void setDataChanged(bool value)
        {
            dataChanged = value;
    //        saveButton.IsEnabled = value;
        }

        /// <summary>
        /// Window closing event handler.
        /// Prompts the user to save data, if it is changed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (dataChanged)
            {
                string message = "Your changes are not saved. Do you want to save it now?";
                MessageBoxResult result = MessageBox.Show(message,
                        this.Title,
                        MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
           //         MonitorModel md = new MonitorModel();
  //                  md.Save(listView1.Items);
                    setDataChanged(false);
                }
                else if (result == MessageBoxResult.Cancel)
                {
                    e.Cancel = true;
                }
                else if (result == MessageBoxResult.No)
                {
                    // do nothing
                }
            }
        }

        /// <summary>
        /// textBox1 KeyDown event handler.
        /// Restores old value, if Esc key is pressed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                RestoreOldValue(sender);
            }
        }

        /// <summary>
        /// Restores old value, saved in Tag property, to textbox.
        /// </summary>
        /// <param name="sender"></param>
        private void RestoreOldValue(object sender)
        {
            TextBox myText = (TextBox)sender;

            if (myText.Text != myText.Tag.ToString())
            {
                myText.Text = myText.Tag.ToString();
                myText.SelectAll();
            }
        }

        /// <summary>
        /// Saves the current value to the Tag property of textbox.
        /// </summary>
        /// <param name="sender"></param>
        private void StoreCurrentValue(object sender)
        {
            TextBox myText = (TextBox)sender;
            myText.Tag = myText.Text;
        }

        /// <summary>
        /// textBox1 GotFocus event handler.
        /// Store the current value and select all text.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox1_GotFocus(object sender, RoutedEventArgs e)
        {
            StoreCurrentValue(sender);
        //    textBox1.SelectAll();
        }

        /// <summary>
        /// textBox2 GotFocus event handler.
        /// Store the current value and select all text.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox2_GotFocus(object sender, RoutedEventArgs e)
        {
            StoreCurrentValue(sender);
        //    textBox2.SelectAll();
        }

        /// <summary>
        /// textBox2 KeyDown event handler.
        /// Restores old value, if Esc key is pressed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                RestoreOldValue(sender);
            }
        }

        private void saveGenerator_Click(object sender, RoutedEventArgs e)
        {
            var op = (OperationType)cbOperation.SelectedIndex;
            var interval = 0;
            int.TryParse(tbInterval.Text, out interval);
            RefreshGeneratorListView(tbGeneratorName.Text, interval, op);

            GeneratorViewModel.Instance.SelectedGeneratorInterval = interval;
            GeneratorViewModel.Instance.SelectedGeneratorName = tbGeneratorName.Text;
            GeneratorViewModel.Instance.SelectedGeneratorOperationInt = interval;

            GeneratorViewModel.Instance.SaveCurrentGenerator();
        }


        private void lvGeneratorList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            GeneratorViewModel.Instance.UpdateGeneratorDetail(lvGeneratorList.SelectedItem as TypeDefs.Generator) ;
        }

        private void lvDataSetList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            GeneratorViewModel.Instance.SelectedDataset = lvDataSetList.SelectedItem as DataSet;
            GeneratorViewModel.Instance.SelectedDatasetIndex = lvDataSetList.SelectedIndex;
            GeneratorViewModel.Instance.UpdateDatasetDetail();
        }


        private void lvDataSetDetail_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lvDataSetDetail!=null && lvDataSetDetail.SelectedItem!=null)
                tbDataSetValue.Text = ((DataSetItem)lvDataSetDetail.SelectedItem).Value.ToString();
            GeneratorViewModel.Instance.SelecteDataSetItem = (DataSetItem)lvDataSetDetail.SelectedItem;
            GeneratorViewModel.Instance.SelectedDatasetItemIndex = lvDataSetDetail.SelectedIndex;
        }

        private void btnRunTests_Click(object sender, RoutedEventArgs e)
        {
            GeneratorModelManager.Instance.RunLoadReadParallel(false,true);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
        //    tbMultiLine.Text += "sdgsdgsgs\r\n"; 
        }

        private void btnAddTexst_Click(object sender, RoutedEventArgs e)
        {
            GeneratorViewModel.Instance.LogStr += "ssdfsdf\r\n";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            tbLog.Text += "KE\r\n";
        }

        private void btnRunGenerator_Click(object sender, RoutedEventArgs e)
        {
            GeneratorViewModel.Instance.RunGeneratorTests();
        }
        public void WriteToLog(string log)
        {
            Dispatcher.Invoke(() =>
            {
                GeneratorViewModel.Instance.LogStr += log + "\r\n";
            });
        }
        private Timer _timer = new Timer();
 
private void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            Dispatcher.Invoke(() =>
            {
                tbLog.Text = GeneratorViewModel.Instance.LogStr;
                // Set property or change UI compomponents.              
            });
        }
        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            GeneratorViewModel.Instance.LogStr += "sdfsdfsf \r\n";
            tbLog.Text = GeneratorViewModel.Instance.LogStr;

        }
    }
}
