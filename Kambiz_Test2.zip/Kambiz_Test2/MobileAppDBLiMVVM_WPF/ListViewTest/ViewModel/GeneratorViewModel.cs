﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using static GeneratorWPF.GeneratorModel;
using GeneratorWPF.MVVMBase;
using GeneratorWPF.Model;
using TypeDefs;
using System.Runtime.CompilerServices;
using System.ComponentModel;

namespace GeneratorWPF.ViewModel
{
    public class GeneratorViewModel : ViewModelBase
    {
        public ObservableCollection<TypeDefs.Generator> GeneratorList { get; set; }
        public ICommand UpdateGeneratorNameCommand { get; set; }
        public string SelectedGeneratorName { get; set; }
        public int SelectedGeneratorInterval { get; set; }
        public OperationType SelectedGeneratorOperation { get; set; }
        public int SelectedGeneratorOperationInt { get
            {
                var res = (int)SelectedGeneratorOperation;
                return res;
            }
            set
            {
                SelectedGeneratorOperation = (OperationType)value;
            }
        }
        public Generator _SelectedGenerator { get; set; }
        public Generator SelectedGenerator
        {
            get
            {
                return _SelectedGenerator;
            }
            set
            {
                try
                {
                    _SelectedGenerator = value;
                    SelectedGeneratorName = value?.name;
                    SelectedGeneratorInterval = value != null ? value.interval : 0;
                    SelectedGeneratorOperation = value != null ? (OperationType)value.OperationEnum :0;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        public void RunGeneratorTests()
        {
            GenReader.GeneratorModelManager.Instance.RunLoadReadParallel(false, true);
        }
        internal void AddDataSetItem()
        {
            SelectedDataset.DataSetItems.Add(new DataSetItem(SelectedDataset.DataSetItems.Count,0));
            GenReader.GeneratorModelManager.Instance.Datasets[SelectedDatasetIndex].Add(0);
            GeneratorViewModel.Instance.UpdateDataSetListRows();
        }

        public string LogStr { get; set; } = "Start...\r\n";
        public String LogOutput
        {
            get { return LogStr; }
            set
            {
                LogStr = value;
                NotifyPropertyChanged();
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void NotifyPropertyChanged([CallerMemberName] String propertyName = "")
        {
            var handler = PropertyChanged;
            if (handler != null)
                handler(this, new PropertyChangedEventArgs(propertyName));
        }

        public static object WriteToLogLock = new object();
       
        public WriteToLogDelegate WriteToLogHandler { get; set; }
        public void WriteToLog(string log)
        {
            lock (WriteToLogLock)
            {
                    try
                    {
                        Console.WriteLine(log);
                    //WriteToLog
                    if (WriteToLogHandler != null)
                        WriteToLogHandler(log);
//                        LogStr += log + "\r\n";
                        RaisePropertyChanged("LogStr");
                    
                    }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
        public GeneratorViewModel()
        {
            UpdateGeneratorNameCommand = new RelayCommand<TypeDefs.Generator>(SelectedGeneratorDetails);
            GeneratorList = GenReader.GeneratorModelManager.Instance.Generators;
            foreach(var gen in GeneratorList)
            {
                gen.WriteToLogHandler -= new WriteToLogDelegate(WriteToLog);
                gen.WriteToLogHandler += new WriteToLogDelegate(WriteToLog);
            }
            UpdateDataSetListRows();
            SelectedGenerator = GeneratorList[0];
            SelectedGeneratorDetails(SelectedGenerator);
            Instance = this;
            this.RaisePropertyChanged("DataSets");
            this.RaisePropertyChanged("SelectedDatasetItems");
            
        }


        public void SelectedGeneratorDetails(TypeDefs.Generator obj)
        {
            if (obj != null)
            {
                this.SelectedGeneratorName = obj.name;
                this.SelectedGeneratorInterval = obj.interval;
                this.SelectedGeneratorOperation = obj.OperationEnum;
                SelectedGenerator = obj;

                // better to go for full property instead of calling property change here 
                this.RaisePropertyChanged("SelectedGeneratorName");
            }
        }
        public ObservableCollection<DataSet> DataSets { get; set; }
        /// <summary>
        /// Saves items to MyData.xml file in bin folder.
        /// </summary>
        /// <param name="items"></param>
        /// <summary>
        /// </summary>
        /// <returns></returns>
        public IEnumerable<object> GetGeneratorRows()
        {
            return GenReader.GeneratorModelManager.Instance.Generators;
        }
        public void UpdateDataSetListRows()
        {
            var datasets = GenReader.GeneratorModelManager.Instance.Datasets;
            DataSets = new ObservableCollection<DataSet>();
            for (int w = 0; w < datasets.Count; w++)
            {
                var ds = new DataSet();
                ds.Index = w;
                ds.DataSetItems = new ObservableCollection<DataSetItem>();
                for (int x = 0; x < datasets[w].Count; x++)
                {
                    var item = new DataSetItem(x, datasets[w][x]);
                    ds.DataSetItems.Add(item);
                }

                DataSets.Add(ds);
            }
        }

        public DataSet SelectedDataset { get; set; }
        public int SelectedDatasetIndex { get; set; }
        public DataSetItem SelecteDataSetItem { get; set; }
        public int SelectedDatasetItemIndex { get; set; }
        public ObservableCollection<DataSetItem> SelectedDatasetItems { get; set; }

        public static GeneratorViewModel Instance { get; set; }
        internal void UpdateGeneratorDetail(Generator generator)
        {
            SelectedGenerator = generator;

            this.RaisePropertyChanged("SelectedGeneratorName");
            this.RaisePropertyChanged("SelectedGeneratorInterval");
            this.RaisePropertyChanged("SelectedGeneratorOperationInt");

        }
        internal void UpdateDatasetDetail()
        {

            var ds = SelectedDataset;
            if (ds != null)
            {
                SelectedDatasetItems = ds.DataSetItems;
            }

            this.RaisePropertyChanged("SelectedDatasetItems");
        }

        public void SaveCurrentGenerator()
        {
            GeneratorWPF.GeneratorModel.Instance.UpdateGenerator(SelectedGenerator, true);
        }
        public void SaveCurrentDataSet()
        {
            GenReader.GeneratorModelManager.Instance.Datasets[SelectedDatasetIndex][SelectedDatasetItemIndex]= SelecteDataSetItem.Value;
            GenReader.GeneratorModelManager.Instance.SaveJSon();

        }

        public void AddDataSetItemToCurrentDataSet(DataSetItem dataSetItem)
        {
            GenReader.GeneratorModelManager.Instance.Datasets[SelectedDatasetIndex].Add(dataSetItem.Value);
            GenReader.GeneratorModelManager.Instance.SaveJSon();
            UpdateDataSetListRows();

        }
        public void RemoveDataSetItemFromCurrentDataSet(int index)
        {
            if (index >= 0 && index < GenReader.GeneratorModelManager.Instance.Datasets[SelectedDatasetIndex].Count)
            {
                if (index >= 0 && index < GeneratorViewModel.Instance.SelectedDatasetItems.Count)
                    GeneratorViewModel.Instance.SelectedDatasetItems.RemoveAt(index);
                GenReader.GeneratorModelManager.Instance.Datasets[SelectedDatasetIndex].RemoveAt(index);
                GenReader.GeneratorModelManager.Instance.SaveJSon();
                UpdateDataSetListRows();
                this.RaisePropertyChanged("SelectedDatasetItems");
            }
        }
    }
}
